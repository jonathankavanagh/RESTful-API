
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes       #-}
{-# LANGUAGE RecordWildCards   #-}
{-# LANGUAGE TemplateHaskell   #-}
{-# LANGUAGE TypeFamilies      #-}
import           Prelude                (IO)
import           GHC.Generics
import           ClassyPrelude
import           Data.Text (Text)
import           Yesod

data CalcAPI = CalcAPI

mkYesod "CalcAPI" [parseRoutes|
/                 IndexRoute GET
/add/#Int/#Int  AdditionRoute  GET
/subtract/#Int/#Int  SubtractionRoute  GET
/divide/#Int/#Int  DivisionRoute  GET
/multiply/#Int/#Int MultiplicationRoute GET

|]

instance Yesod CalcAPI

getIndexRoute :: Handler TypedContent
getIndexRoute = selectRep $ do
    provideRep $ return
        [shamlet|
            <h1 style="color:blue;margin-left:50px"><b>Simple Calculator.</b> <i>Jonathan Kavanagh.</i></h1> <p style="margin-left:50px;"> To Use the Calculator, put the desired function into the URL. For example: http://localhost:3000/<span style="color:red">function</span>/<span style="color:blue">leftnumber</span>/<span style="color:green">rightnumber</span></p><p style="margin-left:50px"> Functions </p><p><span style="color:red;margin-left:50px">/add</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/subtract</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/divide</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/multiply</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><h1 style="margin-left:50px;">Your Sum is: </h1>
        |]


getAdditionRoute :: Int -> Int -> Handler TypedContent
getAdditionRoute a b = selectRep $ do
    provideRep $ return
        [shamlet|
            <h1 style="color:blue;margin-left:50px"><b>Simple Calculator.</b> <i>Jonathan Kavanagh.</i></h1> <p style="margin-left:50px;"> To Use the Calculator, put the desired function into the URL. For example: http://localhost:3000/<span style="color:red">function</span>/<span style="color:blue">leftnumber</span>/<span style="color:green">rightnumber</span></p><p style="margin-left:50px"> Functions </p><p><span style="color:red;margin-left:50px">/add</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/subtract</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/divide</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/multiply</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><h1 style="margin-left:50px;">Your Sum is: <span style="color:blue">#{a}</span> <span style="color:red">+</span> <span style="color:green">#{b}</span> = #{theAnswer}</h1>
        |]
    provideJson theAnswer
  where
  theAnswer = a + b

getSubtractionRoute :: Int -> Int -> Handler TypedContent
getSubtractionRoute a b = selectRep $ do
    provideRep $ return
        [shamlet|
            <h1 style="color:blue;margin-left:50px"><b>Simple Calculator.</b> <i>Jonathan Kavanagh.</i></h1> <p style="margin-left:50px;"> To Use the Calculator, put the desired function into the URL. For example: http://localhost:3000/<span style="color:red">function</span>/<span style="color:blue">leftnumber</span>/<span style="color:green">rightnumber</span></p><p style="margin-left:50px"> Functions </p><p><span style="color:red;margin-left:50px">/add</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/subtract</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/divide</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/multiply</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><h1 style="margin-left:50px;">Your Sum is: <span style="color:blue">#{a}</span> <span style="color:red">-</span> <span style="color:green">#{b}</span> = #{theAnswer}</h1>
        |]
    provideJson theAnswer
  where
  theAnswer = a - b

getDivisionRoute :: Int -> Int -> Handler TypedContent
getDivisionRoute a b = selectRep $ do
    provideRep $ return
        [shamlet|
            <h1 style="color:blue;margin-left:50px"><b>Simple Calculator.</b> <i>Jonathan Kavanagh.</i></h1> <p style="margin-left:50px;"> To Use the Calculator, put the desired function into the URL. For example: http://localhost:3000/<span style="color:red">function</span>/<span style="color:blue">leftnumber</span>/<span style="color:green">rightnumber</span></p><p style="margin-left:50px"> Functions </p><p><span style="color:red;margin-left:50px">/add</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/subtract</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/divide</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/multiply</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><h1 style="margin-left:50px;">Your Sum is: <span style="color:blue">#{a}</span> <span style="color:red">/</span> <span style="color:green">#{b}</span> = #{theAnswer}</h1>
        |]
    provideJson theAnswer
  where
  theAnswer = divisionLogic a b

getMultiplicationRoute :: Int -> Int -> Handler TypedContent
getMultiplicationRoute a b = selectRep $ do
    provideRep $ return
        [shamlet|
            <h1 style="color:blue;margin-left:50px"><b>Simple Calculator.</b> <i>Jonathan Kavanagh.</i></h1> <p style="margin-left:50px;"> To Use the Calculator, put the desired function into the URL. For example: http://localhost:3000/<span style="color:red">function</span>/<span style="color:blue">leftnumber</span>/<span style="color:green">rightnumber</span></p><p style="margin-left:50px"> Functions </p><p><span style="color:red;margin-left:50px">/add</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/subtract</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/divide</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><p><span style="color:red;margin-left:50px">/multiply</span>/<span style="color:blue">left</span>/<span style="color:green">right</span></p><h1 style="margin-left:50px;">Your Sum is: <span style="color:blue">#{a}</span> <span style="color:red">x</span> <span style="color:green">#{b}</span> = #{theAnswer}</h1>
        |]
    provideJson theAnswer
  where
  theAnswer = a * b

divisionLogic :: Int -> Int -> Float
divisionLogic a b = (fromIntegral a) / (fromIntegral b)

main :: IO ()
main = warp 3000 CalcAPI
